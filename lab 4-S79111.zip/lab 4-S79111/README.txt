SWEET SCOOP - ICE CREAM SHOP WEBSITE

FILES
- index.html          Main website (HTML5 semantic structure + navigation + form + video tag)
- style.css           Website styling (CSS selectors, properties, text alignment, link states, responsive layout)
- icecream-poster.svg Video poster image
- icecream.mp4        Short original video used by the HTML5 video tag
- README.txt          Instructions

HOW TO RUN
1. Extract the ZIP file.
2. Open the sweet_scoop_icecream folder.
3. Double-click index.html, or right-click it and choose Open with > Google Chrome.
4. Click the navigation links to move between sections.
5. Try the form at the bottom. It shows a thank-you message (front-end demonstration only).

IMPORTANT
- Keep index.html, style.css, icecream-poster.svg and icecream.mp4 in the same folder.
- The form is a front-end demo. It does not save information to a database.
- Internet is only needed if you want the optional Google Font to load; the website still works without it.

CSS LINK STATES INCLUDED
- a:link
- a:visited
- a:hover
- a:active
